---
title: "Introducing Claude Duet"
source_url: "https://claude.com/resources/articles/claude-duet"
date_extracted: "2026-10-27 20:01"
has_images: true
---

# Introducing Claude Duet

![Imagen Principal](https://claude.com/es/resources/articles/claude-duet/opengraph-image/og)
*(Fuente: claude.com)*

**Enlace original:** [https://claude.com/resources/articles/claude-duet](https://claude.com/resources/articles/claude-duet)

---

A research preview is available by waitlist today, starting with US Pro and Max subscribers.

October 23, 2026 - We’re continuing to develop and strengthen these protections. You can read more about how Claude Duet is designed for safety, privacy and security here.

Today, we’re opening a research preview of Claude Duet, a new app where Claude works as a proactive agent. It comes to you with what needs your attention, completes tasks you ask of it, keeps working even when you step away, and checks with you before it acts on your behalf. We built Claude Duet for professionals and small business owners with more on their plates than they can track.

It’s available as a standalone app on iOS and Android, and on claude.ai. For this research preview, Claude Duet is included in Pro and Max plans and uses the same usage limits as the rest of Claude. To get access, join the waitlist (opens in new tab).

We designed Claude Duet to be a partner you can trust. Professionals of all kinds have to juggle many decisions a day, and we think they’ll find Claude Duet most useful. It helps you prioritize where to spend your time and energy, and to leave room for the ambitious projects that felt impossible or daunting before.

What makes Claude Duet so helpful is its judgment. We designed it around Claude Opus 5.5 (opens in new tab) and built it to be resourceful and to decide what needs you, what can wait, and when to check with you first.

Each morning, it sends you a short brief on the most important items across your connected apps. Throughout the day, it keeps tabs on those apps and messages you only when something needs your attention. You can also hand it tasks of all shapes—from simple administrative tasks of scheduling meetings to more complex ones, such as building dashboards with dozens of tools, creating financial or sales forecasts, prototyping, and building web apps.

Claude Duet draws on years of security, safety, and privacy work on agents, both our own and the infrastructure businesses use to run theirs:

How Claude Duet handles sensitive information. We’re also releasing Claude Duet with a new dedicated classifier and safety system prompt that checks each message and guards against leaks of sensitive information. An agent that reads email and sends messages for you is constantly deciding where information should go. This new classifier and prompt are designed to reject requests to share the strictest tier of information, including credit card numbers and government identification. Other sensitive information, such as health or personal finances, are let through only when you’ve explicitly instructed Claude Duet to send it.

We’re continuing to develop and strengthen these protections, and will share more details about how Claude Duet is designed for safety in the coming days.

People at Anthropic have been using Claude Duet to accomplish more, but also to leave more room for thinking and being present. Boris Cherny, who leads our Claude Code team, talks through his mental to-do list with Claude Duet on walks, instead of saving the work for his desk. Chelsea Larsson, who leads our model and product behavior design team, hands Claude Duet her to-do list before leaving to be with her kids and it saves the results for an evening report. And the team behind Claude Duet uses it to build the product. Karan Ahuja, who leads the team, works with it to schedule user interviews, partner with him on prototypes, and even ship code.

We gave small business owners and entrepreneurs early access to Claude Duet, and some have been using it to help run their businesses. Here’s what some of them said:

Jess gets a rundown from Claude Duet each morning. One day, without being asked, it flagged a property showing that was on her calendar for the wrong day. “[This is] exactly the kind of thing I want caught without having to ask,” she said.

Amin owns Shahs of Kabob in South Florida with about 110 employees. He’s used Claude Duet for accounting, customer support, and marketing, and has worked through his invoices store by store. “It brings it all together,” he said. “I don’t need to open up 100 tabs.”

Mya had a call coming up with a potential client. Claude Duet saw it on her calendar and prepared a brief. It also noticed the call fell right before her flight and offered to move it. “I didn’t realize that it was right before my flight,” she said. “I love that proactivity.”

Your context from Claude is the foundation. Claude Duet carries over your memory, skills, and connected apps from your Claude account, so setting it up requires minimal work. What changes is how you work together: Claude Duet comes to you first, and you can message it through typing or voice in one ongoing thread, so a quick reply and a weeklong project both start in the same place.

Work continues when you step away. Claude Duet has a virtual machine with its own browser, so it doesn’t require your laptop or phone to be on. Describe a task in a short message, and it works out which apps to use and what steps to take in the background. You’ll receive a notification when the task is complete or needs your review.

Receive a message when something needs you. Claude Duet checks your connected accounts every few hours, because checking nonstop would use up your plan’s limits much faster. We’re continuing to test its judgment about when to message you, and we’ll keep tuning it based on what testers tell us. You can also tell it what you want to hear about and how often.

Important decisions stay with you. Claude Duet reads, drafts, and prepares work on its own. But before it sends a message, makes a payment, signs a document, or deletes anything, it shows you exactly what it’s about to do and waits for your approval. A few things are off-limits even with your approval, like trading securities or moving money between accounts. You’re also able to disconnect any app Claude Duet has access to.

Connect with the tools your business runs on. Claude Duet can use the over 6,000 connectors and plugins in the Claude Marketplace (opens in new tab) to:

You can also use Claude Duet to purchase things for your business using Link, Stripe’s digital wallet. Claude Duet confirms the item with you, and Link asks you to approve the spend. It then pays with a virtual card, so your real card number isn’t shared. It can also use Shop Pay from Shopify to check out at online stores. Coming soon, with your permission, it will be able to sign in to sites with logins you’ve saved in 1Password.

This is an early version of Claude Duet, and it still might misread a thread or miscalibrate what’s urgent. We built its core functionality around work, so personal errands, such as booking tickets, aren’t quite as strong, and it can’t yet show you its browser. For now, Claude Duet lives in its own app, separate from the main Claude app. What we learn from early users will shape how the two work together.

During the research preview, Claude Duet shares your plan’s usage limits with the rest of Claude, and it uses them differently than a typical conversation does. Its background checks count toward those limits, and larger tasks, like building a financial model or a deck, require more model turns and background work.

We’re starting today with Pro and Max users in the US. Join the waitlist (opens in new tab) and we’ll email as soon as Claude Duet’s ready for you.

Descubre más novedades del producto y buenas prácticas para los equipos que crean con Claude.

Los asesores financieros ahora pueden conectar Claude a los sistemas de custodia, las plataformas de cartera, los CRM y las herramientas de planificación de los que dependen, además de a nuevas skills adaptadas al trabajo diario de un asesor financiero.

Our new Claude for Nonprofits plugin brings new skills to every verified nonprofit organization, taking on the operational work that stretches small teams across fundraising, marketing, and hiring.

Claude Duet is a proactive agent that works for you, even while you’re away. It builds on two layers of protection: safety training in the Claude model itself and the safeguards that exist in products like Claude Code and Claude Managed Agents. On top of those, we added new protections for working across your accounts and acting on your behalf.

Novedades del producto, tutoriales, destacados de la comunidad y más. Entregado mensualmente en tu bandeja de entrada.

Proporciona tu dirección de correo electrónico si deseas recibir nuestro boletín mensual para desarrolladores. Puedes cancelar la suscripción en cualquier momento.